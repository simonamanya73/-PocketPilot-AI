# PocketPilot AI — Android phone assistant

PocketPilot is a personal-use Android app starter project. It combines voice input, spoken replies, a simple chat screen, Gemini-powered conversation (optional), app launching, and a small set of phone-navigation commands.

## What it can do

- Understand typed commands or speech from the microphone.
- Open installed apps by name, such as WhatsApp, YouTube, Chrome, Camera, or MT5.
- Open Android Settings, Wi-Fi settings, and Bluetooth settings.
- With the Accessibility service enabled, go Home, go Back, show Recents, open notifications, and scroll a scrollable screen.
- Use Gemini 3.8 Flash for general chat and to interpret natural-language requests. A Gemini API key is optional for built-in commands.

## Safety and privacy

- PocketPilot does **not** run a hidden always-listening microphone. You tap the microphone to start speech recognition.
- Its phone-control service only implements an explicit list of navigation actions. It does not type into other apps, tap arbitrary screen buttons, send messages, make calls, pay for things, delete files, or bypass a lock screen.
- Android requires you to manually enable its accessibility permission before navigation commands can work. You can turn it off again in Android Settings → Accessibility.
- If you add a Gemini key, chat text is sent to Google's Gemini API. The key is kept in the app's private SharedPreferences on this device; it is not bundled into the project. Treat it as a password and do not share your key or a device with the key saved.
- This project is unsigned/debug-build oriented. Review the source before installing or sharing any APK.

## Build the APK

### Android Studio / computer

1. Extract this ZIP.
2. Open the `pocketpilot-ai` folder in Android Studio.
3. Install Android SDK Platform 35 and use JDK 17 if Android Studio asks.
4. Run **Build → Build APK(s)**. The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions

The project contains `.github/workflows/build-apk.yml`. Once the *project files* are pushed to a GitHub repository, open **Actions → Build PocketPilot APK → Run workflow** (or push to the `main` branch). Download the `PocketPilot-debug-APK` artifact from that workflow run; it contains `app-debug.apk`.

The ZIP itself is the source project, not an installable APK. If you only have your Android phone, getting the project files into a GitHub repository may require a GitHub-compatible upload workflow or a terminal app with Git. Do not rename the ZIP to `.apk`—that will not install it.

## First launch

1. Install and open PocketPilot AI.
2. To control Home/Back/Recents/scroll, tap **Enable phone control** and enable **PocketPilot phone controls** in Android Accessibility settings. This is an intentionally explicit permission.
3. Tap the microphone and say a command, or type it and tap Send.
4. For general AI chat, tap **API key**, use **Get a key** to open Google AI Studio, create a Gemini API key, paste it in, and save. API access, quota, and any charges depend on Google's current account and service terms.

## Example commands

- `Open WhatsApp`
- `Open YouTube`
- `Open settings`
- `Open Wi-Fi settings`
- `Go home`
- `Go back`
- `Show notifications`
- `Open recent apps`
- `Scroll down`
- `Scroll up`

## Project details

- Package: `com.pocketpilot.assistant`
- Min Android version: Android 8.0 (API 26)
- Compile/target SDK: 35
- Java: 17
- Gemini REST API: `https://generativelanguage.googleapis.com/v1beta/interactions`

## References

- Android Accessibility Service: https://developer.android.com/guide/topics/ui/accessibility/service
- Android SpeechRecognizer: https://developer.android.com/reference/android/speech/SpeechRecognizer
- Gemini API getting started: https://ai.google.dev/gemini-api/docs/get-started
